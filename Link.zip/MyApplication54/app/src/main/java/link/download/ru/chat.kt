package link.download.ru

public class chat{
    var id:String? = null
    var nameOfChat: String? = null
    var avaUrl:String? = null
    var isCall:String? = null
    var lastMessage: String? = null
    var lastMessageTime: String? = null
    var pinnedMessage: String? = null
    var phone: String? = null
    var name: String? = null

    constructor(id: String, nameOfChat: String, avaUrl: String,
                isCall: String, lastMessage: String,lastMessageTime: String,pinnedMessage:String, phone: String, name: String)
    {
        this.id = id
        this.nameOfChat = nameOfChat
        this.avaUrl = avaUrl
        this.isCall = isCall
        this.lastMessage = lastMessage
        this.lastMessageTime = lastMessageTime
        this.pinnedMessage = pinnedMessage
        this.phone = phone
        this.name = name

    }
constructor()
}

