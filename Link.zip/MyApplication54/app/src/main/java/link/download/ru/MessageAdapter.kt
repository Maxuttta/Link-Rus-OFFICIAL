package link.download.ru

    import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
    import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso


class MessageAdapter(val context: Context, val a: String, private val listener: ItemClickListener) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var messageList = mutableListOf<message>()
    val ITEM_FROM = 2
    val ITEM_TO = 1

    lateinit var mDiffResult: DiffUtil.DiffResult

    class MessageToHolder(itemView: View) : RecyclerView.ViewHolder(itemView),View.OnClickListener {
        val text = itemView.findViewById<TextView>(R.id.messageTo)
        val timeText = itemView.findViewById<TextView>(R.id.timeTo)
        val card = itemView.findViewById<ConstraintLayout>(R.id.cardTo)
        val picTo = itemView.findViewById<ImageView>(R.id.picTo)
        val imageTo = itemView.findViewById<CardView>(R.id.imageTo)

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(view: View) {

        }



    }

    class MessageFromHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val text = itemView.findViewById<TextView>(R.id.messageFrom)
        val timeText = itemView.findViewById<TextView>(R.id.timeFrom)
        val card = itemView.findViewById<ConstraintLayout>(R.id.cardFrom)
    }


    override fun getItemViewType(position: Int): Int {
        val currentMessage = messageList[position]
        return if (currentMessage.userId == a) {
            ITEM_TO
        } else {
            ITEM_FROM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return when (viewType) {
            2 -> {
                val view: View = LayoutInflater.from(context)
                    .inflate(R.layout.activity_message_from_item, parent, false)
                MessageFromHolder(view)
            }

            1 -> {
                val view: View = LayoutInflater.from(context)
                    .inflate(R.layout.activity_message_to_item, parent, false)
                MessageToHolder(view)
            }

            else -> {
                val view: View = LayoutInflater.from(context)
                    .inflate(R.layout.activity_message_to_item, parent, false)

                MessageToHolder(view)
            }
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.setOnClickListener {
            showPopupMenu(it, position)
        }
        val currentMessage = messageList[position]
        if (holder.javaClass == MessageAdapter.MessageToHolder::class.java) {
            val holder = holder as MessageAdapter.MessageToHolder
            holder.text.text = currentMessage.title
            holder.timeText.text = currentMessage.time
            if (currentMessage.messageType == "text") {
                holder.text.textSize = 16F
                holder.card.setBackgroundResource(R.drawable.message_to)
                if (currentMessage.pictureUrl != ""){
                    holder.imageTo.visibility = View.VISIBLE
                    holder.picTo.maxWidth = 100
                    Picasso.get().load(currentMessage.pictureUrl).into(holder.picTo)
                }
                else{

                }
            }
            if (currentMessage.messageType == "emoji") {
                holder.text.textSize = 90F
                holder.card.setBackgroundResource(R.color.invisible)
            }
        } else {
            val holder = holder as MessageAdapter.MessageFromHolder
            holder.text.text = currentMessage.title
            holder.timeText.text = currentMessage.time
            if (currentMessage.messageType == "text") {
                holder.text.textSize = 16F
                holder.card.setBackgroundResource(R.drawable.message_from)
            }
            else {
                holder.text.textSize = 90F
                holder.card.setBackgroundResource(R.color.invisible)
            }
        }

    }

    override fun getItemCount(): Int {
        return messageList.size
    }

    fun addItem(item: message) {
        val newList = mutableListOf<message>()
        newList.addAll(messageList)
        newList.add(item)
        mDiffResult = DiffUtil.calculateDiff(DiffUtilCallback(messageList, newList))
        mDiffResult.dispatchUpdatesTo(this)
        messageList = newList
    }

    fun updateItem(item: message) {
        val index = messageList.indexOfFirst { it.messageId == item.messageId }
        if (index != -1) {
            val newList = mutableListOf<message>()
            newList.addAll(messageList)
            newList[index] = item
            mDiffResult = DiffUtil.calculateDiff(DiffUtilCallback(messageList, newList))
            mDiffResult.dispatchUpdatesTo(this)
            messageList = newList
        } else {
            addItem(item)
        }
    }

    fun removeItem(item: message) {
        val index = messageList.indexOfFirst { it.messageId == item.messageId }
        if (index != -1) {
            val newList = messageList.toMutableList()
            newList.removeAt(index)
            mDiffResult = DiffUtil.calculateDiff(DiffUtilCallback(messageList, newList))
            mDiffResult.dispatchUpdatesTo(this)
            messageList = newList
            notifyItemRemoved(index)
            notifyItemRangeChanged(index, messageList.size - newList.size)
        }
    }
    private fun showPopupMenu(view: View, position: Int) {
        val message = messageList[position]
        val popupMenu = PopupMenu(context, view)
        popupMenu.menuInflater.inflate(R.menu.message_menu, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.delete -> {
                    listener.onDeleteClicked(position, message)
                    true
                }
                R.id.edit -> {
                    listener.onEditClicked(position, message)
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

    interface ItemClickListener {
        fun onDeleteClicked(position: Int, message: message)
        fun onEditClicked(position: Int, message: message)
    }

    interface Listener{
        fun onClick(message: message)
    }

//    @SuppressLint("NotifyDataSetChanged")
//    fun  addMessage(message: message){
//        messageList.add(message)
//        notifyDataSetChanged()
//    }

}