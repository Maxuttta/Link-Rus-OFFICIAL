package link.download.ru


class MyNotificationListenerService {
//    override fun onMessageReceived(remoteMessage: onlineData) {
//        val builder: NotificationCompat.Builder = NotificationCompat.Builder(this)
//            .setSmallIcon(R.mipmap.sym_def_app_icon)
//            .setContentTitle("Title")
//            .setContentText("Notification text")
//
//        val notification = builder.build()
//
//        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager?
//        notificationManager!!.notify(1, notification)
//    }

}