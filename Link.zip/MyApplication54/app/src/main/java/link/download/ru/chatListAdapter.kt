package link.download.ru

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import link.download.ru.databinding.UserChatItemBinding

class chatListAdapter(val listener:Listener): RecyclerView.Adapter<chatListAdapter.ChatHolder>(){
    var chatList:List<chat> = mutableListOf<chat>()
    lateinit var mDiffResult: DiffUtil.DiffResult

    class ChatHolder(item: View): RecyclerView.ViewHolder(item){
        private val binding = UserChatItemBinding.bind(item)
        var isCall = ""
        var pin = ""
        fun bind(chat:chat, listener: Listener) = with(binding){
//            userAva.setBackgroundResource(chat.avaUrl)
            userNameText.text = chat.nameOfChat
            lastMessage.text = chat.lastMessage
            lastMessageTime.text = chat.lastMessageTime
            isCall = chat.isCall.toString()
            pin = chat.pinnedMessage.toString()
            if ((pin != "-") && (isCall != "true")){
                extraCard.visibility = View.VISIBLE
                extraText.visibility = View.GONE
                context.visibility = View.VISIBLE
                context.text = pin
            }
            if (isCall == "true"){
                extraCard.visibility = View.VISIBLE
                extraText.visibility = View.VISIBLE
                extraImage.setBackgroundResource(R.drawable.baseline_phone_24_2)
                extraText.text = "Идет звонок"
                context.visibility = View.VISIBLE
                context.text = "Х человек в звонке"
            }
            itemView.setOnClickListener {
                listener.onClick(chat)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.user_chat_item,parent,false)
        return ChatHolder(view)
    }

    override fun getItemCount(): Int {
        return chatList.size
    }

    override fun onBindViewHolder(holder: ChatHolder, position: Int) {
        holder.bind(chatList[position], listener)
    }

//    @SuppressLint("NotifyDataSetChanged")
//    fun  addChat(chat: chat){
//        chatList.add(chat)
//        notifyDataSetChanged()
//    }
    fun addChat(item: chat){
        val newList = mutableListOf<chat>()
        newList.addAll(chatList)
        newList.add(item)
        mDiffResult = DiffUtil.calculateDiff(chatDiffUtil(chatList, newList))
        mDiffResult.dispatchUpdatesTo(this)
        chatList = newList
}

    fun updateItem(item: chat) {
        val index = chatList.indexOfFirst { it.id == item.id }
        if (index != -1) {
            val newList = mutableListOf<chat>()
            newList.addAll(chatList)
            newList[index] = item
            mDiffResult = DiffUtil.calculateDiff(chatDiffUtil(chatList, newList))
            mDiffResult.dispatchUpdatesTo(this)
            chatList = newList
        } else {
            addChat(item)
        }
    }
//    fun setData(newData: MutableList<chat>){
//        chatList = newData
//        notifyDataSetChanged()
//    }
    interface Listener{
        fun onClick(chat: chat)
    }

}