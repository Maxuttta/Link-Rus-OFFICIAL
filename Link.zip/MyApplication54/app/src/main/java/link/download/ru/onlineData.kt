package link.download.ru

class onlineData{
    var status: String? = null
    var time: String? = null
    constructor(status:String, time: String){
        this.status = status
        this.time = time
    }
    constructor()
}